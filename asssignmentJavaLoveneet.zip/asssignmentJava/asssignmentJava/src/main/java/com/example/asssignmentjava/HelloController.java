package com.example.asssignmentjava;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class HelloController {

    @FXML
    private BarChart<String, Integer> barChart;

    public void chart() {
        String chartSQL = "SELECT country, EV_count FROM EV_Countries GROUP BY country, EV_count ORDER BY TIMESTAMP(country) ASC LIMIT 5";

        DatabaseConnector dbConnector = new DatabaseConnector();
        Connection connection = dbConnector.connectDB();

        try {
            XYChart.Series<String, Integer> chartData = new XYChart.Series<>();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(chartSQL);

            while (resultSet.next()) {
                chartData.getData().add(new XYChart.Data<>(resultSet.getString(1), resultSet.getInt(2)));
            }

            resultSet.close();
            statement.close();

            barChart.getData().add(chartData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
